<?php
// process_form.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$servername = "localhost";
$username = "root";
$password = "yourpassword";
$dbname = "Greenvale"; // replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Retrieve form data
  $equipment = $_POST["equipment"];
  $duration = $_POST["duration"];
  $fname = $_POST["fname"];
  $lname = $_POST["lname"];
  $address = $_POST["address"];
  $license = $_POST["license"];
  $dob = $_POST["dob"];
  $date_needed = $_POST["date_needed"];
  $cc = $_POST["cc"];
$exp_date = $_POST["exp_date"];
$exp_date = DateTime::createFromFormat('m/y', $exp_date)->format('Y-m-t');

  $cvv = $_POST["cvv"];
  $comments = $_POST["comments"];

  // Insert data into the database
  $sql = "INSERT INTO Rental (EquipmentID, RentalDuration, FirstName, LastName, DeliveryAddress, DriversLicenseID, DOB, DateNeeded, CreditCardNumber, ExpiryDate, CVV, AdditionalComments) VALUES ('$equipment', '$duration', '$fname', '$lname', '$address', '$license', '$dob', '$date_needed', '$cc', '$exp_date', '$cvv', '$comments')";

  if ($conn->query($sql) === TRUE) {
    header("Location: rental.html"); // replace with the name of your HTML file
    exit;
} else {
    echo "Error: " . $sql . "<br>" . $conn->connect_error;
}

}

$conn->close();
?>
