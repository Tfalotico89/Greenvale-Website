<?php
$servername = "localhost";
$username = "root";
$password = "yourpassword";
$dbname = "Greenvale"; // replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Fetch feedbacks from the database based on the selected equipment
$equipment = $_POST["equipment"]; // Changed 'feedback-equipment' to 'equipment'
$sql = $equipment == "all" ? "SELECT * FROM Feedback" : "SELECT * FROM Feedback WHERE EquipmentID = '$equipment'";

$result = $conn->query($sql);

$feedbacks = array();
if ($result->num_rows > 0) {
  // Output data of each row
  while($row = $result->fetch_assoc()) {
    $feedbacks[] = $row;
  }
} 

echo json_encode($feedbacks);

$conn->close();

?>
