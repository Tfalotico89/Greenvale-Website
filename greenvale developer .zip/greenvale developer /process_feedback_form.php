<?php
// process_feedback_form.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$servername = "localhost";
$username = "root";
$password = "yourpassword";
$dbname = "Greenvale"; // replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Retrieve form data
  $equipment = $_POST["equipment"];
  $feedback = $_POST["feedback"];

  // Insert data into the database
  $sql = "INSERT INTO Feedback (EquipmentID, FeedbackText) VALUES ('$equipment', '$feedback')";

  if ($conn->query($sql) === TRUE) {
    echo "<script type='text/javascript'>
            alert('New feedback submitted successfully');
            window.location='contactus.html';
          </script>";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->connect_error;
  }
}

$conn->close();
?>
